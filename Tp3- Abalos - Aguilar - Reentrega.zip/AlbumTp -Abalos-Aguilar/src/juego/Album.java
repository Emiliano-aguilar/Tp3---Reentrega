package juego;

import java.util.HashSet;

public class Album {
	private HashSet<Figurita> album;
	
	
	
	

	public Album(HashSet<Figurita> album) {
		this.album = album;
	}

	



	public HashSet<Figurita> getAlbum() {
		return album;
	}
	
	public int tamanio() {
		return album.size();
	}
	


	
	
	
}
