package juego;

import java.util.ArrayList;
import java.util.HashSet;

public class Usuario {
	private Album album;
	private ArrayList<Figurita> figuritasRepetidas;
	private int cantidadDeFigusDonadasOIntercambiadas;

	public Usuario(Album album, ArrayList<Figurita> figuritasRepetidas) {
		this.album = album;
		this.figuritasRepetidas = figuritasRepetidas;
		this.cantidadDeFigusDonadasOIntercambiadas = 0;
	}

	public HashSet<Figurita> getAlbum() {
		return album.getAlbum();

	}

	public ArrayList<Figurita> getFiguritasRepetidas() {
		return figuritasRepetidas;
	}

	public int getCantidadDeFigusDonadasOIntercambiadas() {
		return cantidadDeFigusDonadasOIntercambiadas;
	}

	public void usuarioDono() {
		this.cantidadDeFigusDonadasOIntercambiadas++;
	}

	public boolean albumCompleto() {
		if (album.getAlbum().size() == 638) {
			return true;
		}
		return false;
	}

	// inicia en falso, si tiene la figurita repetida, retorna true, sino falso
	public boolean pegarFigurita(Figurita figu) {
		boolean flag = false;
		for (Figurita figurita : getAlbum()) {
			if (figurita.getNumeroFigurita() == figu.getNumeroFigurita()) {
				flag = true;
			}
		}
		return flag;

	}

	public ArrayList<Figurita> dameFiguritasRepetidas() {
		ArrayList<Figurita> figusRepetidas = this.figuritasRepetidas;
		return figusRepetidas;
	}

	public boolean puedeIntercambiar() {
		return (figuritasRepetidas.size() > 0);
	}

	public void agregarARepetidas(Figurita figu) {
		figuritasRepetidas.add(figu);
	}

	public void agregarFigurita(Figurita figu) {
		getAlbum().add(figu);
	}

	public void agregarFiguritasAAlbum(Figurita figu) {
		if (!pegarFigurita(figu)) {
			agregarFigurita(figu);
		} else {
			agregarARepetidas(figu);
		}

	}

	public int cantidadFiguritasEnAlbum() {
		return getAlbum().size();
	}

}
