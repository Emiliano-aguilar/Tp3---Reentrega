package juego;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class conDonaciones extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField CantSimulaciones;
	private JLabel CantidadFiguritasObtenidas;
	private JLabel CantidadPaquetesAbiertos;
	private JLabel CantidadDineroGastado;
	private JLabel PromedioPaquetes;
	private JLabel CantidadDeSimulaciones;
	private Integer cantSim;
	private Integer CantUser;
	private JTextField cantUsuarios;
	private JLabel UsIngresados;
	private JLabel DonacionesHechas;
	private juegoInterno nuevo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Solitario frame = new Solitario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public conDonaciones() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 628, 631);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(139, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel(
				"------------------------------------------------------------------------------");
		lblNewLabel.setBounds(-12, 422, 679, 14);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 25));
		contentPane.add(lblNewLabel);

		nuevo = new juegoInterno();

		inicializarLabels();

		JButton btnNewButton_1 = new JButton("Empezar Simulacion");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				cantSim = inicializarCantSimulaciones();
				CantUser = inicializarCantUsuarios();
				nuevo.inicializarSimulacionesDonacion(CantUser, cantSim);

				actualizarLabels();

			}

		});
		btnNewButton_1.setIcon(new ImageIcon(Solitario.class.getResource("/Image/FONDOBOTON4 (1).png")));
		btnNewButton_1.setBounds(10, 531, 280, 50);
		contentPane.add(btnNewButton_1);

		JButton btnNewButton = new JButton("RESET");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				restablecerDatos();
			}

		});
		btnNewButton.setBounds(432, 531, 132, 50);
		contentPane.add(btnNewButton);

	}

	private void restablecerDatos() {
		nuevo.restablecerDatos();
		CantidadDineroGastado.setText(pasarAString(nuevo.getDineroGastado()) + "$");
		CantidadFiguritasObtenidas.setText(pasarAString(nuevo.getCantFigusObt()));
		PromedioPaquetes.setText(pasarAString(nuevo.getPaquetesPromedio()));
		CantidadPaquetesAbiertos.setText(pasarAString(nuevo.getCantPaquetesAbiertos()));
		CantidadDeSimulaciones.setText(pasarAString(nuevo.getCantSim()));
		UsIngresados.setText(pasarAString(nuevo.getCantUser()));
		DonacionesHechas.setText(pasarAString(nuevo.getCantDon()));
	}

	private int inicializarCantSimulaciones() {
		Integer CantSim;

		if (CantSimulaciones.getText().isEmpty()) {
			CantSim = 1;
		} else {
			CantSim = Integer.parseInt(CantSimulaciones.getText());

		}
		return CantSim;
	}

	private int inicializarCantUsuarios() {
		Integer CantUser;

		if (cantUsuarios.getText().isEmpty()) {
			CantUser = 2;
		} else {
			CantUser = Integer.parseInt(cantUsuarios.getText());

		}
		return CantUser;
	}


	private void actualizarLabels() {
		CantidadDineroGastado.setText(pasarAString(nuevo.getDineroGastado()) + "$");
		CantidadFiguritasObtenidas.setText(pasarAString(nuevo.getCantFigusObt()));
		PromedioPaquetes.setText(pasarAString(nuevo.getPaquetesPromedio()));
		CantidadPaquetesAbiertos.setText(pasarAString(nuevo.getCantPaquetesAbiertos()));
		CantidadDeSimulaciones.setText(pasarAString(nuevo.getCantSim()));
		UsIngresados.setText(pasarAString(nuevo.getCantUser()));
		DonacionesHechas.setText(pasarAString(nuevo.getCantDon()));

	}

	private void inicializarLabels() {

		JLabel LOGO = new JLabel("");
		LOGO.setIcon(new ImageIcon(Solitario.class.getResource("/Image/UNGS.png")));
		LOGO.setBounds(410, 0, 94, 62);
		contentPane.add(LOGO);

		JLabel lblDatos = new JLabel("DATOS:");
		lblDatos.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblDatos.setForeground(new Color(255, 255, 255));
		lblDatos.setBounds(10, 11, 94, 23);
		contentPane.add(lblDatos);

		JLabel lblNewLabel_1 = new JLabel("FIGURITAS EN LOS ALBUMES:");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(10, 70, 280, 23);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("CANTIDAD DE PAQUETES ABIERTOS:");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setBounds(10, 120, 344, 23);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("PROMEDIO DE PAQUETES PARA LLENAR EL ALBUN:");
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNewLabel_3.setBounds(10, 220, 415, 14);
		contentPane.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("DINERO GASTADO:");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setBounds(10, 170, 184, 23);
		contentPane.add(lblNewLabel_4);

		CantSimulaciones = new JTextField();
		CantSimulaciones.setBounds(344, 447, 86, 20);
		contentPane.add(CantSimulaciones);
		CantSimulaciones.setColumns(10);

		JLabel lblNewLabel_5 = new JLabel("Ingrese la cantidad de simulaciones a realizar:");
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_5.setForeground(new Color(255, 255, 255));
		lblNewLabel_5.setBounds(10, 448, 332, 17);
		contentPane.add(lblNewLabel_5);
		JLabel lblNewLabel_6 = new JLabel("CANTIDAD DE SIMULACIONES:");
		lblNewLabel_6.setForeground(new Color(255, 255, 255));
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_6.setBounds(10, 270, 293, 14);
		contentPane.add(lblNewLabel_6);

		CantidadDeSimulaciones = new JLabel("");
		CantidadDeSimulaciones.setForeground(new Color(255, 255, 255));
		CantidadDeSimulaciones.setFont(new Font("Times New Roman", Font.BOLD, 18));
		CantidadDeSimulaciones.setBounds(292, 270, 86, 14);
		contentPane.add(CantidadDeSimulaciones);

		CantidadFiguritasObtenidas = new JLabel("");
		CantidadFiguritasObtenidas.setForeground(new Color(255, 255, 255));
		CantidadFiguritasObtenidas.setFont(new Font("Times New Roman", Font.BOLD, 18));
		CantidadFiguritasObtenidas.setBounds(292, 73, 86, 17);
		contentPane.add(CantidadFiguritasObtenidas);
		CantidadFiguritasObtenidas.setText(pasarAString(nuevo.getCantFigusObt()));

		CantidadPaquetesAbiertos = new JLabel("");
		CantidadPaquetesAbiertos.setFont(new Font("Times New Roman", Font.BOLD, 18));
		CantidadPaquetesAbiertos.setForeground(new Color(255, 255, 255));
		CantidadPaquetesAbiertos.setBounds(344, 123, 86, 17);
		contentPane.add(CantidadPaquetesAbiertos);
		CantidadPaquetesAbiertos.setText(pasarAString(nuevo.getCantPaquetesAbiertos()));

		CantidadDineroGastado = new JLabel("");
		CantidadDineroGastado.setFont(new Font("Times New Roman", Font.BOLD, 18));
		CantidadDineroGastado.setForeground(new Color(255, 255, 255));
		CantidadDineroGastado.setBounds(188, 173, 115, 17);
		contentPane.add(CantidadDineroGastado);
		CantidadDineroGastado.setText(pasarAString(nuevo.getDineroGastado()) + "$");

		PromedioPaquetes = new JLabel("");
		PromedioPaquetes.setForeground(new Color(255, 255, 255));
		PromedioPaquetes.setFont(new Font("Times New Roman", Font.BOLD, 18));
		PromedioPaquetes.setBounds(421, 215, 115, 23);
		contentPane.add(PromedioPaquetes);
		PromedioPaquetes.setText(pasarAString(nuevo.getPaquetesPromedio()));

		JLabel lblNewLabel_7 = new JLabel("Ingrese cantidad de usuarios:");
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_7.setForeground(new Color(255, 255, 255));
		lblNewLabel_7.setBounds(10, 492, 239, 14);
		contentPane.add(lblNewLabel_7);

		cantUsuarios = new JTextField();
		cantUsuarios.setBounds(346, 491, 86, 20);
		contentPane.add(cantUsuarios);
		cantUsuarios.setColumns(10);

		JLabel cantUsuariosIngresados = new JLabel("CANTIDAD DE USUARIOS INGRESADOS:");
		cantUsuariosIngresados.setFont(new Font("Times New Roman", Font.BOLD, 18));
		cantUsuariosIngresados.setForeground(new Color(255, 255, 255));
		cantUsuariosIngresados.setBounds(10, 320, 368, 14);
		contentPane.add(cantUsuariosIngresados);

		UsIngresados = new JLabel("");
		UsIngresados.setFont(new Font("Times New Roman", Font.BOLD, 18));
		UsIngresados.setForeground(new Color(255, 255, 255));
		UsIngresados.setBounds(369, 320, 77, 14);
		contentPane.add(UsIngresados);

		JLabel DonacionesHechasLabel = new JLabel("PROMEDIO DE FIGURITAS DONADAS POR USUARIO:");
		DonacionesHechasLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		DonacionesHechasLabel.setForeground(new Color(255, 255, 255));
		DonacionesHechasLabel.setBounds(10, 370, 478, 14);
		contentPane.add(DonacionesHechasLabel);

		DonacionesHechas = new JLabel("");
		DonacionesHechas.setForeground(new Color(255, 255, 255));
		DonacionesHechas.setFont(new Font("Times New Roman", Font.BOLD, 18));
		DonacionesHechas.setBounds(480, 370, 122, 23);
		contentPane.add(DonacionesHechas);
		DonacionesHechas.setText(pasarAString(nuevo.getCantDon()));

	}

	private String pasarAString(int num) {
		return String.valueOf(num);
	}
}
