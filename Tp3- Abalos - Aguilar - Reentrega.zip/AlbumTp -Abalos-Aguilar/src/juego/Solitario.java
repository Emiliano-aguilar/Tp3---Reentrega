package juego;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class Solitario extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField CantSimulaciones;
	private JLabel CantidadFiguritasObtenidas;
	private JLabel CantidadPaquetesAbiertos;
	private JLabel CantidadDineroGastado;
	private JLabel PromedioPaquetes;
	private JLabel CantidadaDeSimulaciones;
	private Integer cantSim;
	private juegoInterno nuevo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Solitario frame = new Solitario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Solitario() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 520, 501);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(139, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("--------------------------------------------------------------------");
		lblNewLabel.setBounds(0, 310, 531, 14);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 25));
		contentPane.add(lblNewLabel);

		 nuevo = new juegoInterno();

		inicializarLabels();

		JButton btnNewButton_1 = new JButton("Empezar Simulacion");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				cantSim = inicializarCantSimulaciones();
				nuevo.iniciarSimulacionSolitario(cantSim);
				actualizarLabels();

			}
		});
		btnNewButton_1.setIcon(new ImageIcon(Solitario.class.getResource("/Image/FONDOBOTON4 (1).png")));
		btnNewButton_1.setBounds(22, 388, 280, 50);
		contentPane.add(btnNewButton_1);

		JButton btnNewButton = new JButton("RESET");
		btnNewButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				restablecerDatos();
			}

		});
		btnNewButton.setBounds(359, 388, 132, 50);
		contentPane.add(btnNewButton);

	}

	private void restablecerDatos() {
		nuevo.restablecerDatos();

		CantidadDineroGastado.setText(pasarAString(nuevo.getDineroGastado()) + "$");
		CantidadFiguritasObtenidas.setText(pasarAString(nuevo.getCantFigusObt()));
		PromedioPaquetes.setText(pasarAString(nuevo.getPaquetesPromedio()));
		CantidadPaquetesAbiertos.setText(pasarAString(nuevo.getCantPaquetesAbiertos()));
		CantidadaDeSimulaciones.setText(pasarAString(nuevo.getCantSim()));

	}

	private int inicializarCantSimulaciones() {
		Integer CantSim;

		if (CantSimulaciones.getText().isEmpty()) {
			CantSim = 1;
		} else {
			CantSim = Integer.parseInt(CantSimulaciones.getText());

		}
		return CantSim;
	}

	private void actualizarLabels() {
		CantidadDineroGastado.setText(pasarAString(nuevo.getDineroGastado()) + "$");
		CantidadFiguritasObtenidas.setText(pasarAString(nuevo.getCantFigusObt()));
		PromedioPaquetes.setText(pasarAString(nuevo.getPaquetesPromedio()));
		CantidadPaquetesAbiertos.setText(pasarAString(nuevo.getCantPaquetesAbiertos()));
		CantidadaDeSimulaciones.setText(pasarAString(nuevo.getCantSim()));

	}

	private void inicializarLabels() {

		JLabel LOGO = new JLabel("");
		LOGO.setIcon(new ImageIcon(Solitario.class.getResource("/Image/UNGS.png")));
		LOGO.setBounds(410, 0, 94, 62);
		contentPane.add(LOGO);

		JLabel lblDatos = new JLabel("DATOS:");
		lblDatos.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblDatos.setForeground(new Color(255, 255, 255));
		lblDatos.setBounds(10, 11, 94, 23);
		contentPane.add(lblDatos);

		JLabel lblNewLabel_1 = new JLabel("FIGURITAS EN EL ALBUN:");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(9, 75, 254, 23);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("CANTIDAD DE PAQUETES ABIERTOS:");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setBounds(10, 120, 344, 23);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("PROMEDIO DE PAQUETES PARA LLENAR EL ALBUN:");
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNewLabel_3.setBounds(10, 215, 415, 14);
		contentPane.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("DINERO GASTADO:");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setBounds(10, 170, 184, 23);
		contentPane.add(lblNewLabel_4);

		CantSimulaciones = new JTextField();
		CantSimulaciones.setBounds(344, 337, 86, 20);
		contentPane.add(CantSimulaciones);
		CantSimulaciones.setColumns(10);

		JLabel lblNewLabel_5 = new JLabel("Ingrese la cantidad de simulaciones a realizar:");
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_5.setForeground(new Color(255, 255, 255));
		lblNewLabel_5.setBounds(22, 338, 332, 17);
		contentPane.add(lblNewLabel_5);
		JLabel lblNewLabel_6 = new JLabel("CANTIDAD DE SIMULACIONES:");
		lblNewLabel_6.setForeground(new Color(255, 255, 255));
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_6.setBounds(10, 260, 293, 14);
		contentPane.add(lblNewLabel_6);

		CantidadaDeSimulaciones = new JLabel("");
		CantidadaDeSimulaciones.setForeground(new Color(255, 255, 255));
		CantidadaDeSimulaciones.setFont(new Font("Times New Roman", Font.BOLD, 18));
		CantidadaDeSimulaciones.setBounds(293, 260, 86, 14);
		contentPane.add(CantidadaDeSimulaciones);

		CantidadFiguritasObtenidas = new JLabel("");
		CantidadFiguritasObtenidas.setForeground(new Color(255, 255, 255));
		CantidadFiguritasObtenidas.setFont(new Font("Times New Roman", Font.BOLD, 18));
		CantidadFiguritasObtenidas.setBounds(255, 78, 86, 17);
		contentPane.add(CantidadFiguritasObtenidas);
		CantidadFiguritasObtenidas.setText(pasarAString(nuevo.getCantFigusObt()));

		CantidadPaquetesAbiertos = new JLabel("");
		CantidadPaquetesAbiertos.setFont(new Font("Times New Roman", Font.BOLD, 18));
		CantidadPaquetesAbiertos.setForeground(new Color(255, 255, 255));
		CantidadPaquetesAbiertos.setBounds(344, 123, 86, 17);
		contentPane.add(CantidadPaquetesAbiertos);
		CantidadPaquetesAbiertos.setText(pasarAString(nuevo.getCantPaquetesAbiertos()));

		CantidadDineroGastado = new JLabel("");
		CantidadDineroGastado.setFont(new Font("Times New Roman", Font.BOLD, 18));
		CantidadDineroGastado.setForeground(new Color(255, 255, 255));
		CantidadDineroGastado.setBounds(191, 173, 115, 17);
		contentPane.add(CantidadDineroGastado);
		CantidadDineroGastado.setText(pasarAString(nuevo.getDineroGastado()) + "$");

		PromedioPaquetes = new JLabel("");
		PromedioPaquetes.setForeground(new Color(255, 255, 255));
		PromedioPaquetes.setFont(new Font("Times New Roman", Font.BOLD, 18));
		PromedioPaquetes.setBounds(410, 210, 94, 23);
		contentPane.add(PromedioPaquetes);
		PromedioPaquetes.setText(pasarAString(nuevo.getPaquetesPromedio()));
	}

	private String pasarAString(int num) {
		return String.valueOf(num);
	}
}
