package juego;

public interface Generador {
	
	int nextInt(int rango);
}
