package juego;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class juegoInterno {
	private static Generador _random;
	private int CantFigusObt = 0;
	private int CantPaquetesAbiertos = 0;
	private int dineroGastado = 0;
	private int paquetesPromedio = 0;
	private int precioPaquete = 150;
	private int cantSim;
	private Usuario usuario;
	private int CantUser;
	private int cantInt;
	private int cantDon;

	public Integer getCantInt() {
		return cantInt;
	}

	public Integer getCantUser() {
		return CantUser;
	}

	public static void setGenerador(Generador generador) {
		_random = generador;

	}

	public juegoInterno() {
		_random = new GeneradorAleatorio();
	}

	public void llenarAlbum(Usuario us) {
		agregarAAlum(us, damePaquete());
	}

	public void llenarAlbumConDonacion(ArrayList<Usuario> usuarios, Usuario us) {
		agregarAABumConDonacion(usuarios, us, damePaquete());

	}

	public void llenarAlbumConDonacionManual(ArrayList<Usuario> usuarios, Usuario us, ArrayList<Figurita> paquete) {
		agregarAAlum(us, paquete);
		intercambiarFiguritas(usuarios, us);
	}

	public void agregarAAlum(Usuario us, ArrayList<Figurita> figuritas) {
		for (int i = 0; i < figuritas.size(); i++) {
			us.agregarFiguritasAAlbum(figuritas.get(i));
		}

	}

	public void agregarAABumConDonacion(ArrayList<Usuario> usuarios, Usuario us, ArrayList<Figurita> figuritas) {

		int contador = usuarios.size();
		for (int i = 0; i < figuritas.size(); i++) {
			boolean flag2 = false;

			us.agregarFiguritasAAlbum(figuritas.get(i));

			for (int j = 0; j < usuarios.size(); j++) {
				int iterador = 0;
				while (!flag2) {
					flag2 = tieneFigurita(usuarios.get(j), figuritas.get(i));
					if (flag2 == true) {
						us.usuarioDono();
					}
					iterador++;

					if (contador == iterador) {
						break;
					}
				}

			}

		}
	}

	public void intercambiarFiguritas(ArrayList<Usuario> usuarios, Usuario us) {
		Integer cantidadIntercambiadas = 0;
		Iterator<Figurita> figuritaUserPrincipal = us.getFiguritasRepetidas().iterator();

		while (figuritaUserPrincipal.hasNext()) {
			boolean flag = false;
			Figurita figu1 = figuritaUserPrincipal.next();
			for (Usuario usuario : usuarios) {
				if (!figuritaRepetida(usuario, figu1) && usuario.puedeIntercambiar()) {
					Iterator<Figurita> figuritaUserSecundario = usuario.getFiguritasRepetidas().iterator();
					while (figuritaUserSecundario.hasNext()) {
						Figurita figu2 = figuritaUserSecundario.next();
						if (!figuritaRepetida(us, figu2) && !flag) {
							// el usuario princiapl agrega la figurita
							us.agregarFigurita(figu2);
							// el 2do usuario agrega la figurita
							usuario.agregarFigurita(figu1);
							flag = true;
							// eliminamos ambas figuritas de los albumnes repetidos de cada uno
							figuritaUserSecundario.remove();
							figuritaUserPrincipal.remove();

							cantidadIntercambiadas++;
							us.usuarioDono();
						}
					}
				}
			}

		}
	}

	public boolean tieneFigurita(Usuario us, Figurita figu) {
		boolean flag = true;

		if (us.pegarFigurita(figu)) {
			flag = false;
		}

		if (flag) {
			us.agregarFigurita(figu);
		}

		return flag;

	}

	// Este metodo devuelve un paquete de 5 figuritas
	public ArrayList<Figurita> damePaquete() {

		ArrayList<Figurita> paquete = new ArrayList<Figurita>();

		for (int i = 0; i < 5; i++) {
			paquete.add(dameFigurita(dameRandom()));
		}
		return paquete;
	}

	// Este metodo da un numero random del 1 al 638
	public Integer dameRandom() {
		return _random.nextInt(638);
	}

	public boolean figuritaRepetida(Usuario us, Figurita figuritaUserPrincipal) {

		return us.pegarFigurita(figuritaUserPrincipal);
	}

	// Este metodo nos da la figurita dependiendo el numero que le pasemos
	public Figurita dameFigurita(int i) {
		Figurita figurita = new Figurita(i);
		return figurita;
	}

	protected Usuario inicializarUsuario() {
		Album a = new Album(new HashSet<Figurita>());
		ArrayList<Figurita> figuritasRepetidas = new ArrayList<Figurita>();
		Usuario usuario = new Usuario(a, figuritasRepetidas);
		return usuario;
	}

	protected void iniciarSimulacionSolitario(int cantSim) {
		this.cantSim = cantSim;
		for (int i = 0; i < cantSim; i++) {
			usuario = inicializarUsuario();
			int CantPaquetesAbiertosAux = 0;
			int CantFigusObtAux = 0;
			int dineroGastadoAux = 0;
			int contador = 0;

			// mientras el usuario no completa el album, se ejecuta el juego
			while (!usuario.albumCompleto()) {

				contador++;
				llenarAlbum(usuario);
			}
			CantPaquetesAbiertosAux = contador;
			CantFigusObtAux = usuario.cantidadFiguritasEnAlbum();
			dineroGastadoAux = CantPaquetesAbiertosAux * precioPaquete;
			CantPaquetesAbiertos = CantPaquetesAbiertos + CantPaquetesAbiertosAux;
			CantFigusObt = CantFigusObt + CantFigusObtAux;
			dineroGastado = dineroGastado + dineroGastadoAux;
			paquetesPromedio = CantPaquetesAbiertos / cantSim;

		}

	}

	protected void inicializarSimulacionIntercambio(int CantUser, int cantSim) {
		this.CantUser = CantUser;
		this.cantSim = cantSim;
		ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
		int contador = 0;
	

		for (int i = 0; i < cantSim; i++) {

			int CantPaquetesAbiertosAux = 0;
			int CantFigusObtAux = 0;
			int dineroGastadoAux = 0;
			int cantIntercambiadasAux = 0;
			
			for (int k = 0; k < CantUser; k++) {
				usuarios.add(inicializarUsuario());
			}

			while (!todosCompletos(usuarios)) {

				for (int j = 0; j < usuarios.size(); j++) {

					if (!usuarios.get(j).albumCompleto()) {
						contador++;
						llenarAlbumConDonacionManual(usuarios, usuarios.get(j), damePaquete());
						cantIntercambiadasAux = usuarios.get(j).getCantidadDeFigusDonadasOIntercambiadas();
					}
				}
			}

			CantPaquetesAbiertosAux = contador;
			CantFigusObtAux = usuarios.get(0).cantidadFiguritasEnAlbum() * usuarios.size();
			dineroGastadoAux = CantPaquetesAbiertosAux * precioPaquete;
			cantInt = cantInt + cantIntercambiadasAux;
			CantPaquetesAbiertos = CantPaquetesAbiertos + CantPaquetesAbiertosAux;
			CantFigusObt = CantFigusObt + CantFigusObtAux;
			dineroGastado = dineroGastado + dineroGastadoAux;
			paquetesPromedio = CantPaquetesAbiertos ;
			usuarios.clear();
		}
		paquetesPromedio = paquetesPromedio / cantSim / CantUser;
		cantInt = cantInt / cantSim / CantUser;
	}

	protected void inicializarSimulacionesDonacion(int CantUser, int cantSim) {
		this.CantUser = CantUser;
		this.cantSim = cantSim;
		ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
		int contador = 0;

		for (int i = 0; i < cantSim; i++) {
			int CantPaquetesAbiertosAux = 0;
			int CantFigusObtAux = 0;
			int dineroGastadoAux = 0;
			int cantidadDonacionesAux = 0;
			
			for (int k = 0; k < CantUser; k++) {
				usuarios.add(inicializarUsuario());
			}

			while (!todosCompletos(usuarios)) {
				for (int j = 0; j < usuarios.size(); j++) {

					if (!usuarios.get(j).albumCompleto()) {
						contador++;
						llenarAlbumConDonacion(usuarios, usuarios.get(j));
						cantidadDonacionesAux =  usuarios.get(j).getCantidadDeFigusDonadasOIntercambiadas();

					}
					
					
				}

			}

			CantPaquetesAbiertosAux = contador;
			CantFigusObtAux = usuarios.get(0).cantidadFiguritasEnAlbum() * usuarios.size();
			dineroGastadoAux = CantPaquetesAbiertosAux * precioPaquete;
			cantDon =  cantDon + cantidadDonacionesAux;
			CantPaquetesAbiertos = CantPaquetesAbiertos + CantPaquetesAbiertosAux;
			CantFigusObt = CantFigusObt + CantFigusObtAux;
			dineroGastado = dineroGastado + dineroGastadoAux;
			paquetesPromedio = CantPaquetesAbiertos;
			usuarios.clear();
			
		}
		
		paquetesPromedio = paquetesPromedio / cantSim / CantUser;
		cantDon = cantDon / cantSim / CantUser;
		

	}

	private boolean todosCompletos(ArrayList<Usuario> usuarios) {
		boolean flag = true;
		for (int i = 0; i < usuarios.size(); i++) {
			flag = flag && usuarios.get(i).albumCompleto();
		}

		return flag;
	}

	public void restablecerDatos() {
		CantPaquetesAbiertos = 0;
		CantFigusObt = 0;
		dineroGastado = 0;
		paquetesPromedio = 0;
		cantSim = 0;
		CantUser = 0;
		cantInt = 0;
		cantDon = 0;
	}

	public int getCantFigusObt() {
		return CantFigusObt;
	}

	public int getCantPaquetesAbiertos() {
		return CantPaquetesAbiertos;
	}

	public int getDineroGastado() {
		return dineroGastado;
	}

	public int getPaquetesPromedio() {
		return paquetesPromedio;
	}

	public int getPrecioPaquete() {
		return precioPaquete;
	}

	public int getCantSim() {
		return cantSim;
	}

	public int getCantDon() {
		return cantDon;
	}

}
